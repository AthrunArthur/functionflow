ff
==

FF's common used C++ code. 
If you have C++11, this code utilize C++11, and only depends C++11.
Otherwise, this code depends on boost, including boost_thread, boost_system and boost_date_time.

===
ff only includes header file, you don't need to compile it and link it. Just include it.

CUrrently, ff includes several components.

1. blocking queue (thread safe!)
2. nonblock queue (thread safe!)
3. log utilities.

###Notice
